local strAddonName, tblNamespace = ...

local tblHelpers = tblNamespace.Helpers
local tblCore = tblNamespace.Core
local tblOptions = tblNamespace.Options
local tblEvents = tblNamespace.Events
local tblState = tblNamespace.State

--========================================================
-- Events
--========================================================
function tblEvents.OnAddonLoaded()
	tblHelpers.EnsureDB()
	tblCore.ApplySavedLayout()
	tblCore.ApplyBackdrop()
	tblOptions.CreateOptionsPanel()
	tblCore.ApplyLockState()
end

function tblEvents.OnTargetChanged()
	local frmModel = tblState.frmModel

	tblState.intModelApplyToken = tblState.intModelApplyToken + 1
	frmModel._applyToken = tblState.intModelApplyToken

	local intToken = frmModel._applyToken
	local blnUseTarget = UnitExists("target") and true or false
	local strDesiredUnit = blnUseTarget and "target" or "player"

	frmModel._desiredUnit = strDesiredUnit
	frmModel._desiredGUID = UnitGUID(strDesiredUnit)

	if frmModel._lastUnit ~= strDesiredUnit then
		frmModel._needsHardReset = true
	end
	frmModel._lastUnit = strDesiredUnit

	tblCore.ForceSetModelUnit(blnUseTarget)
	tblHelpers.DebugSnapshot("TargetChanged POST SetUnit (immediate)", intToken)
end

function tblEvents.OnEnteringWorld()
	local frmModel = tblState.frmModel

	tblState.intModelApplyToken = tblState.intModelApplyToken + 1
	frmModel._applyToken = tblState.intModelApplyToken

	local intToken = frmModel._applyToken
	local strDesiredUnit = "player"

	frmModel._desiredUnit = strDesiredUnit
	frmModel._desiredGUID = UnitGUID(strDesiredUnit)

	if frmModel._lastUnit ~= strDesiredUnit then
		frmModel._needsHardReset = true
	end
	frmModel._lastUnit = strDesiredUnit

	tblCore.ForceSetModelUnit(false)
	tblHelpers.DebugSnapshot("EnteringWorld POST SetUnit (immediate)", intToken)

	if frmModel and frmModel._KickApplyPipeline then
		frmModel._KickApplyPipeline(intToken)
	end
end

function tblEvents.OnEvent(_frmSelf, _strEvent, _valArgument1)
	if _strEvent == "ADDON_LOADED" and _valArgument1 == tblNamespace.strAddonName then
		tblEvents.OnAddonLoaded()
	elseif _strEvent == "PLAYER_TARGET_CHANGED" then
		tblEvents.OnTargetChanged()
	elseif _strEvent == "PLAYER_ENTERING_WORLD" then
		tblEvents.OnEnteringWorld()
	end
end

--========================================================
-- Boot
--========================================================
tblCore.CreateMainFrame()
tblCore.CreateBorderOverlay()
tblCore.CreateModel()
tblCore.CreateResizeGrip()
tblCore.WireFrameInteraction()

tblCore.ApplyBackdrop()

tblState.frmMain:RegisterEvent("ADDON_LOADED")
tblState.frmMain:RegisterEvent("PLAYER_TARGET_CHANGED")
tblState.frmMain:RegisterEvent("PLAYER_ENTERING_WORLD")
tblState.frmMain:SetScript("OnEvent", tblEvents.OnEvent)